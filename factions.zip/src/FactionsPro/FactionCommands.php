<?php

namespace FactionsPro;

use pocketmine\plugin\PluginBase;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\Player;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\utils\TextFormat;
use pocketmine\scheduler\PluginTask;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\Config;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;

class FactionCommands {
	
	public $plugin;
	
	public function __construct(FactionMain $pg) {
		$this->plugin = $pg;
	}
	
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
		if($sender instanceof Player) {
			$player = $sender->getPlayer()->getName();
			if(strtolower($command->getName('g'))) {
				if(empty($args)) {
					$sender->sendMessage($this->plugin->formatMessage("Użyj /g komendy aby wyświetlić komendy"));
				}
				if(count($args == 2)) {
					
					/////////////////////////////// CREATE ///////////////////////////////
					
					if($args[0] == "stworz") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g stworz <nazwa>"));
							return true;
						}
						if(!(ctype_alnum($args[1]))) {
							$sender->sendMessage($this->plugin->formatMessage("Możesz jedynie użyj liter i liczb!"));
							return true;
						}
						if($this->plugin->isNameBanned($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Wystąpił błąd w nazwie gildi, zmień nazwe."));
							return true;
						}
						if($this->plugin->factionExists($args[1]) == true ) {
							$sender->sendMessage($this->plugin->formatMessage("Ta nazwa jest zajęta"));
							return true;
						}
						if(strlen($args[1]) > $this->plugin->prefs->get("MaxFactionNameLength")) {
							$sender->sendMessage($this->plugin->formatMessage("Nazwa gildi jest za krótka!"));
							return true;
						}
						if($this->plugin->isInFaction($sender->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz najpierw obuścić gildie"));
							return true;
						} else {
							$factionName = $args[1];
							$player = strtolower($player);
							$rank = "Leader";
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
							$stmt->bindValue(":player", $player);
							$stmt->bindValue(":faction", $factionName);
							$stmt->bindValue(":rank", $rank);
							$result = $stmt->execute();
							$this->plugin->updateTag($player);
							$sender->sendMessage($this->plugin->formatMessage("Gildia została utworzona!", true));
							return true;
						}
					}
					
					/////////////////////////////// INVITE ///////////////////////////////
					
					if($args[0] == "zapros") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g zapros <gracz>"));
							return true;
						}
						if( $this->plugin->isFactionFull($this->plugin->getPlayerFaction($player)) ) {
							$sender->sendMessage($this->plugin->formatMessage("Gildia jest pełna."));
							return true;
						}
						$invited = $this->plugin->getServer()->getPlayerExact($args[1]);
						if($this->plugin->isInFaction($invited) == true) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz jest już w gildi"));
							return true;
						}
						if($this->plugin->prefs->get("OnlyLeadersCanInvite") & !($this->plugin->isLeader($player))) {
							$sender->sendMessage($this->plugin->formatMessage("Tylko lider może zapraszać"));
							return true;
						}
						if(!$invited instanceof Player) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz nie jest online!"));
							return true;
						}
						if($invited->isOnline() == true) {
							$factionName = $this->plugin->getPlayerFaction($player);
							$invitedName = $invited->getName();
							$rank = "Member";
								
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO confirm (player, faction, invitedby, timestamp) VALUES (:player, :faction, :invitedby, :timestamp);");
							$stmt->bindValue(":player", strtolower($invitedName));
							$stmt->bindValue(":faction", $factionName);
							$stmt->bindValue(":invitedby", $sender->getName());
							$stmt->bindValue(":timestamp", time());
							$result = $stmt->execute();
	
							$sender->sendMessage($this->plugin->formatMessage("$invitedName został zaproszony!", true));
							$invited->sendMessage($this->plugin->formatMessage("Zostałeś zaproszony do $factionName. Wpisz '/g akceptuj' aby akceptować lub '/g odrzuć' aby odrzucić!", true));
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Gracz nie jest online!"));
						}
					}
					
					/////////////////////////////// LEADER ///////////////////////////////
					
					if($args[0] == "lider") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g lider <gracz>"));
							return true;
						}
						if(!$this->plugin->isInFaction($sender->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildi aby przekazać lidera"));
						}
						if(!$this->plugin->isLeader($player)) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być liderem przekazać lidera"));
						}
						if($this->plugin->getPlayerFaction($player) != $this->plugin->getPlayerFaction($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("• Najpierw dodaj gracza do gildi!"));
						}		
						if(!$this->plugin->getServer()->getPlayerExact($args[1])->isOnline()) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz nie jest online"));
						}
							$factionName = $this->plugin->getPlayerFaction($player);
							$factionName = $this->plugin->getPlayerFaction($player);
	
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
							$stmt->bindValue(":player", $player);
							$stmt->bindValue(":faction", $factionName);
							$stmt->bindValue(":rank", "Member");
							$result = $stmt->execute();
	
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
							$stmt->bindValue(":player", strtolower($args[1]));
							$stmt->bindValue(":faction", $factionName);
							$stmt->bindValue(":rank", "Leader");
							$result = $stmt->execute();
	
	
							$sender->sendMessage($this->plugin->formatMessage("Przekazałeś lidera!", true));
							$this->plugin->getServer()->getPlayer($args[1])->sendMessage($this->plugin->formatMessage("Zostałeś liderem gildi \n $factionName!",  true));
							$this->plugin->updateTag($sender->getName());
							$this->plugin->updateTag($this->plugin->getServer()->getPlayer($args[1])->getName());
						}
					
					/////////////////////////////// PROMOTE ///////////////////////////////
					
					if($args[0] == "awansuj") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g awansuj <gracz>"));
							return true;
						}
						if(!$this->plugin->isInFaction($sender->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildi aby awansować gracza!"));
							return true;
						}
						if(!$this->plugin->isLeader($player)) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być liderem aby przekazać lidera!"));
							return true;
						}
						if($this->plugin->getPlayerFaction($player) != $this->plugin->getPlayerFaction($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz nie jest w tej gildi!"));
							return true;
						}
						if($this->plugin->isOfficer($this->plugin->getServer()->getPlayer($args[1])->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz jest już oficerem"));
							return true;
						}
						$factionName = $this->plugin->getPlayerFaction($player);
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
						$stmt->bindValue(":player", strtolower($args[1]));
						$stmt->bindValue(":faction", $factionName);
						$stmt->bindValue(":rank", "Officer");
						$result = $stmt->execute();
						$player = $this->plugin->getServer()->getPlayer($args[1]);
						$sender->sendMessage($this->plugin->formatMessage("" . $player->getName() . " został awansowany na oficera!", true));
						$player->sendMessage($this->plugin->formatMessage("Zostałeś oficerem!", true));
						$this->plugin->updateTag($player->getName());
					}
					
					/////////////////////////////// DEMOTE ///////////////////////////////
					
					if($args[0] == "zwolnij") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g zwolnij <gracz>"));
							return true;
						}
						if($this->plugin->isInFaction($sender->getName()) == false) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildi aby tego użyć!"));
							return true;
						}
						if($this->plugin->isLeader($player) == false) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być liderem aby tego użyć"));
							return true;
						}
						if($this->plugin->getPlayerFaction($player) != $this->plugin->getPlayerFaction($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz nie jest w gildi!"));
							return true;
						}
						if(!$this->plugin->isOfficer($this->plugin->getServer()->getPlayer($args[1])->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz nie posiada oficera"));
							return true;
						}
						$factionName = $this->plugin->getPlayerFaction($player);
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
						$stmt->bindValue(":player", strtolower($args[1]));
						$stmt->bindValue(":faction", $factionName);
						$stmt->bindValue(":rank", "Member");
						$result = $stmt->execute();
						$player = $this->plugin->getServer()->getPlayer($args[1]);
						$sender->sendMessage($this->plugin->formatMessage("" . $player->getName() . " został zwolniony z rangi oficer.", true));
						$player->sendMessage($this->plugin->formatMessage("Zostałeś zwolniony z rangi oficer.", true));
						$this->plugin->updateTag($player->getName());
					}
					
					/////////////////////////////// KICK ///////////////////////////////
					
					if($args[0] == "wyrzuc") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g wyrzuc <gracz>"));
							return true;
						}
						if($this->plugin->isInFaction($sender->getName()) == false) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildi aby wyrzucić gracza"));
							return true;
						}
						if($this->plugin->isLeader($player) == false) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być liderem aby wyrzucić gracza"));
							return true;
						}
						if($this->plugin->getPlayerFaction($player) != $this->getPlayerFaction($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz nie jest w gildi!"));
							return true;
						}
						$kicked = $this->plugin->getServer()->getPlayerExact($args[1]);
						$factionName = $this->plugin->getPlayerFaction($player);
						$this->plugin->db->query("DELETE FROM master WHERE player='$args[1]';");
						$sender->sendMessage($this->plugin->formatMessage("Wyrzuciłeś gracza $args[1]!", true));
						$players[] = $this->plugin->getServer()->getOnlinePlayers();
						if(in_array($args[1], $players) == true) {
							$this->plugin->getServer()->getPlayer($args[1])->sendMessage($this->plugin->formatMessage("Zostałeś wyrzucony z gildi \n $factionName!, true"));
							$this->plugin->updateTag($args[1]);
							return true;
						}
					}

					
					/////////////////////////////// INFO ///////////////////////////////
					
					if(strtolower($args[0]) == 'info') {
						if(isset($args[1])) {
							if( !(ctype_alnum($args[1])) | !($this->plugin->factionExists($args[1]))) {
								$sender->sendMessage($this->plugin->formatMessage("Niema takiej gildi"));
								return true;
							}
							$faction = strtolower($args[1]);
							$leader = $this->plugin->getLeader($faction);
							$numPlayers = $this->plugin->getNumberOfPlayers($faction);
							$sender->sendMessage(TextFormat::GREEN . "• ======================== •");
							$sender->sendMessage("$faction");
							$sender->sendMessage(TextFormat::RED . "• Lider: " . TextFormat::RESET . "$leader");
							$sender->sendMessage(TextFormat::RED . " • # liczba graczy: " . TextFormat::RESET . "$numPlayers");
							$sender->sendMessage(TextFormat::RED . "• MOTD: " . TextFormat::RESET . "$message");
							$sender->sendMessage(TextFormat::GREEN . "• ======================== •");
						} else {
							$faction = $this->plugin->getPlayerFaction(strtolower($sender->getName()));
							$result = $this->plugin->db->query("SELECT * FROM motd WHERE faction='$faction';");
							$array = $result->fetchArray(SQLITE3_ASSOC);
							$message = $array["message"];
							$leader = $this->plugin->getLeader($faction);
							$numPlayers = $this->plugin->getNumberOfPlayers($faction);
							$sender->sendMessage(TextFormat::GREEN . "• ======================= •");
							$sender->sendMessage("$faction");
							$sender->sendMessage(TextFormat::RED . "• Lider: " . TextFormat::RESET . "$leader");
							$sender->sendMessage(TextFormat::RED . "• # liczba graczy: " . TextFormat::RESET . "$numPlayers");
							$sender->sendMessage(TextFormat::RED . "• MOTD: " . TextFormat::RESET . "$message");
							$sender->sendMessage(TextFormat::RED . "•==========================");
						}
					}
					if(strtolower($args[0]) == "komendy") {
						if(!isset($args[1]) || $args[1] == 1) {
							$sender->sendMessage(TextFormat::BLUE . "GildiePro komendy strona 1 z 3" . TextFormat::GREEN . "\n§o§6• /g autor\n§o§6• /g akceptuj\n§o§6• /g nowadzialka\n§o§6• /g stworz <nazwa>\n§o§6• /g usun\n§o§6• /g zwolnij <gracz>\n§o§6• /g odrzuc");
							return true;
						}
						if($args[1] == 2) {
							$sender->sendMessage(TextFormat::BLUE . "GildiePro komendy strona 2 z 3" . TextFormat::RED . "\n§o§6• /g dom\n§o§6• /g komendy <strona>\n§o§6• /g info\n§o§6• /g info <gildia>\n§o§6• /g zapros <gracz>\n§o§6• /g wyrzuc <gracz>\n§o§6• /g lider <gracz>\n§o§6• /g wyjdz");
							return true;
						} else {
							$sender->sendMessage(TextFormat::BLUE . "GildiePro komendy strona 3 z 3" . TextFormat::RED . "\n§o§6• /g motd\n§o§6• /g awansuj <gracz>\n§o§6 /g ustawdom\n§o§6• /g usundzialke\n§o§6 /g usundom");
							return true;
						}
					}
				}
				if(count($args == 1)) {
					
					/////////////////////////////// CLAIM ///////////////////////////////
					
	 				if(strtolower($args[0]) == 'nowadzialka') {
						if(!$this->plugin->isInFaction($player)) {
							$player->sendMessage($this->plugin->formatMessage("Musisz być s drużynie!."));
						}
						if(!$this->plugin->isLeader($player)) {
							$player->sendMessage($this->plugin->formatMessage("Musisz być liderem aby tego użyć."));
						}
						$x = floor($sender->getX());
						$y = floor($sender->getY());
						$z = floor($sender->getZ());
						$faction = $this->plugin->getPlayerFaction($sender->getPlayer()->getName());
						$this->plugin->drawPlot($player, $faction, $x, $y, $z, $sender->getPlayer()->getLevel(), $this->plugin->prefs->get("PlotSize"));
						$sender->sendMessage($this->plugin->formatMessage("Działka została utworzona.", true));
					}
					
					/////////////////////////////// UNCLAIM ///////////////////////////////
					
					if(strtolower($args[0]) == "usundzialke") {
						if(!$this->plugin->isLeader($sender->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być liderem aby tego uźyć."));
							return true;
						}
						$faction = $this->plugin->getPlayerFaction($sender->getName());
						$this->plugin->db->query("DELETE FROM plots WHERE faction='$faction';");
						$sender->sendMessage($this->plugin->formatMessage("Działka skasowana.", true));
					}
					
					/////////////////////////////// MOTD ///////////////////////////////
					
					if(strtolower($args[0]) == "motd") {
						if($this->plugin->isInFaction($sender->getName()) == false) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildi!"));
							return true;
						}
						if($this->plugin->isLeader($player) == false) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być liderem"));
							return true;
						}
						$sender->sendMessage($this->plugin->formatMessage("Type your message in chat. It will not be visible to other players", true));
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO motdrcv (player, timestamp) VALUES (:player, :timestamp);");
						$stmt->bindValue(":player", strtolower($sender->getName()));
						$stmt->bindValue(":timestamp", time());
						$result = $stmt->execute();
					}
					
					/////////////////////////////// ACCEPT ///////////////////////////////
					
					if(strtolower($args[0]) == "akceptuj") {
						$player = $sender->getName();
						$lowercaseName = strtolower($player);
						$result = $this->plugin->db->query("SELECT * FROM confirm WHERE player='$lowercaseName';");
						$array = $result->fetchArray(SQLITE3_ASSOC);
						if(empty($array) == true) {
							$sender->sendMessage($this->plugin->formatMessage("Nie masz zaproszeń!"));
							return true;
						}
						$invitedTime = $array["timestamp"];
						$currentTime = time();
						if( ($currentTime - $invitedTime) <= 60 ) { //This should be configurable
							$faction = $array["faction"];
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
							$stmt->bindValue(":player", strtolower($player));
							$stmt->bindValue(":faction", $faction);
							$stmt->bindValue(":rank", "Member");
							$result = $stmt->execute();
							$this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
							$sender->sendMessage($this->plugin->formatMessage("Dołaczyłeś do gildi $faction!", true));
							$this->plugin->getServer()->getPlayerExact($array["invitedby"])->sendMessage($this->plugin->formatMessage("$player gracz dołaczył do gildi!", true));
							$this->plugin->updateTag($sender->getName());
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Invite has timed out!"));
							$this->plugin->db->query("DELETE * FROM confirm WHERE player='$player';");
						}
					}
					
					/////////////////////////////// DENY ///////////////////////////////
					
					if(strtolower($args[0]) == "odrzuc") {
						$player = $sender->getName();
						$lowercaseName = strtolower($player);
						$result = $this->plugin->db->query("SELECT * FROM confirm WHERE player='$lowercaseName';");
						$array = $result->fetchArray(SQLITE3_ASSOC);
						if(empty($array) == true) {
							$sender->sendMessage($this->plugin->formatMessage("Nie masz żadnych aktywnych zaproszeń!"));
							return true;
						}
						$invitedTime = $array["timestamp"];
						$currentTime = time();
						if( ($currentTime - $invitedTime) <= 60 ) { //This should be configurable
							$this->plugin->db->query("DELETE * FROM confirm WHERE player='$lowercaseName';");
							$sender->sendMessage($this->plugin->formatMessage("Zaproszenie odrzucone!", true));
							$this->plugin->getServer()->getPlayerExact($array["invitedby"])->sendMessage($this->plugin->formatMessage("$player odrzucił zaproszenie!"));
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Zaproszenie wygasło"));
							$this->plugin->db->query("DELETE * FROM confirm WHERE player='$lowercaseName';");
						}
					}
					
					/////////////////////////////// DELETE ///////////////////////////////
					
					if(strtolower($args[0]) == "usun") {
						if($this->plugin->isInFaction($player) == true) {
							if($this->plugin->isLeader($player)) {
								$faction = $this->plugin->getPlayerFaction($player);
								$this->plugin->db->query("DELETE FROM master WHERE faction='$faction';");
								$sender->sendMessage($this->plugin->formatMessage("Gildia została usunieta", true));
								$this->plugin->updateTag($sender->getName());
							} else {
								$sender->sendMessage($this->plugin->formatMessage("Nie jesteś liderem!"));
							}
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Nie jesteś w gildi!"));
						}
					}
					
					/////////////////////////////// LEAVE ///////////////////////////////
					
					if(strtolower($args[0] == "wyjdz")) {
						if($this->plugin->isLeader($player) == false) {
							$remove = $sender->getPlayer()->getNameTag();
							$faction = $this->plugin->getPlayerFaction($player);
							$name = $sender->getName();
							$this->plugin->db->query("DELETE FROM master WHERE player='$name';");
							$sender->sendMessage($this->plugin->formatMessage("Odszedłeś z $faction", true));
							$this->plugin->updateTag($sender->getName());
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Musisz usunąć gildie lub przekazać lidera!"));
						}
					}
					
					/////////////////////////////// SETHOME ///////////////////////////////
					
					if(strtolower($args[0] == "ustawdom")) {
						if(!$this->plugin->isInFaction($player)) {
							$player->sendMessage($this->plugin->formatMessage("Musisz być w gildi aby ustawić dom."));
						}
						if(!$this->plugin->isLeader($player)) {
							$player->sendMessage($this->plugin->formatMessage("Musisz być liderem aby ustawić dom."));
							return true;
						}
						$factionName = $this->plugin->getPlayerFaction($sender->getName());
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO home (faction, x, y, z) VALUES (:faction, :x, :y, :z);");
						$stmt->bindValue(":faction", $factionName);
						$stmt->bindValue(":x", $sender->getX());
						$stmt->bindValue(":y", $sender->getY());
						$stmt->bindValue(":z", $sender->getZ());
						$result = $stmt->execute();
						$sender->sendMessage($this->plugin->formatMessage("Dom ustawiony!", true));
					}
					
					/////////////////////////////// UNSETHOME ///////////////////////////////
						
					if(strtolower($args[0] == "usundom")) {
						if(!$this->plugin->isInFaction($player)) {
							$player->sendMessage($this->plugin->formatMessage("Musisz być w gildi aby usunąć dom."));
						}
						if(!$this->plugin->isLeader($player)) {
							$player->sendMessage($this->plugin->formatMessage("Musisz być liderem aby usunąć dom"));
							return true;
						}
						$faction = $this->plugin->getPlayerFaction($sender->getName());
						$this->plugin->db->query("DELETE FROM home WHERE faction = '$faction';");
						$sender->sendMessage($this->plugin->formatMessage("Home unset!", true));
					}
					
					/////////////////////////////// HOME ///////////////////////////////
						
					if(strtolower($args[0] == "dom")) {
						if(!$this->plugin->isInFaction($player)) {
							$player->sendMessage($this->plugin->formatMessage("Musisz być w gildi."));
						}
						$faction = $this->plugin->getPlayerFaction($sender->getName());
						$result = $this->plugin->db->query("SELECT * FROM home WHERE faction = '$faction';");
						$array = $result->fetchArray(SQLITE3_ASSOC);
						if(!empty($array)) {
							$sender->getPlayer()->teleport(new Vector3($array['x'], $array['y'], $array['z']));
							$sender->sendMessage($this->plugin->formatMessage("Teleportowano.", true));
							return true;
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Dom nie jest ustawiony."));
							}
						}
					
					/////////////////////////////// ABOUT ///////////////////////////////
					
					if(strtolower($args[0] == 'autor')) {
						$sender->sendMessage(TextFormat::BLUE . "GildiePro v1.3.0 by " . TextFormat::BOLD . "Tethered_\n" . TextFormat::RESET . TextFormat::BLUE . "Twitter: " . TextFormat::ITALIC . "@Tethered_");
					}
				} else {
					$sender->sendMessage($this->plugin->formatMessage("Użyj /g komendy aby wyświetlić komendy"));
				}
			}
		} else {
			$this->plugin->getServer()->getLogger()->info($this->plugin->formatMessage("Użyj tej komendy w grze"));
		}
	}
}